export const indexToAlphabet = (index) => {
    return String.fromCharCode('A'.charCodeAt(0) + index);
}