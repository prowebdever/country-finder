import darkBackground from './sources/dark.jpg'

export const images = {
    darkBackground
}