import { createAction } from "@reduxjs/toolkit";
export const getCountryList = createAction("COUNTRYLIST");